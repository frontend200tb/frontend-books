const dataVacancy = [

  {
    id: 1,
    theme: 'Vacancy',
    header2: 'Вакансии',
  },

  {
    id: 2,
    theme: 'Vacancy',
    header3: 'Вакансии',
    link: 'https://voronezh.hh.ru/',
    name: 'voronezh.hh.ru',
  },

  {
    id: 3,
    theme: 'Vacancy',
    header3: 'Вакансии',
    link: 'https://career.habr.com/',
    name: 'career.habr.com',
  },

  {
    id: 4,
    theme: 'Vacancy',
    header3: 'Вакансии',
    link: 'https://www.rabota.ru/',
    name: 'rabota.ru',
  },

  {
    id: 5,
    theme: 'Vacancy',
    header3: 'Вакансии',
    link: 'https://vc.ru/job',
    name: 'vc.ru/job',
  },

  {},

];

export default dataVacancy;
