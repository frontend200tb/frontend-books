const dataBooksBootstrap = [

  {
    id: 1,
    year: 2016,
    category: 'framework',
    theme: 'bootstrap',
    title: 'Bootstrap Быстрое создание современных сайтов',
    author: 'Машнин',
    authorName: 'Тимур',
    pages: '145',
    isLearned: true,
    dateLearned: '2021-08-14 сб',
  },

  {
    id: 2,
    year: 2016,
    category: 'framework',
    theme: 'bootstrap',
    title: 'Bootstrap. Руководство',
    author: 'Мержевич',
    authorName: 'Влад',
    pages: '58',
    isLearned: true,
    dateLearned: '2021-08-12 чт',
  },

  {
    id: 3,
    year: 2017,
    category: 'framework',
    theme: 'bootstrap',
    title: 'Bootstrap в примерах',
    author: 'Морето',
    authorName: 'Сильвио',
    pages: '314',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 4,
    year: 2021,
    category: 'framework',
    theme: 'bootstrap',
    title: 'Bootstrap и CSS-препроцессор Sass',
    author: 'Прохоренок',
    authorName: 'Николай',
    pages: '497',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataBooksBootstrap;
