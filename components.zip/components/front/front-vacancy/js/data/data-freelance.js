const dataFreelance = [

  {
    id: 1,
    theme: 'Freelance',
    header2: 'Фриланс Биржа',
  },

  {
    id: 2,
    theme: 'Freelance',
    header3: 'Взять заказы',
    link: 'https://www.fl.ru/',
    name: 'fl.ru',
  },

  {
    id: 3,
    theme: 'Freelance',
    header3: 'Взять заказы',
    link: 'https://freelance.ru/',
    name: 'freelance.ru',
  },

  {
    id: 4,
    theme: 'Freelance',
    header3: 'Взять заказы',
    link: 'https://freelance.habr.com/',
    name: 'freelance.habr.com',
  },

  {
    id: 5,
    theme: 'Freelance',
    header3: 'Взять заказы',
    link: 'https://freelancehunt.com/',
    name: 'freelancehunt.com',
  },

  {
    id: 6,
    theme: 'Freelance',
    header3: 'Взять заказы',
    link: 'https://www.freelancejob.ru/',
    name: 'freelancejob.ru',
  },

  {
    id: 7,
    theme: 'Freelance',
    header3: 'Взять заказы',
    link: 'https://www.freelancer.com.ru/',
    name: 'freelancer.com.ru',
  },

  {
    id: 8,
    theme: 'Freelance',
    header3: 'Взять заказы',
    link: 'https://freten.ru/',
    name: 'freten.ru',
  },

  {
    id: 9,
    theme: 'Freelance',
    header3: 'Взять заказы',
    link: 'https://kwork.ru/',
    name: 'kwork.ru',
  },

  {
    id: 10,
    theme: 'Freelance',
    header3: 'Взять заказы',
    link: 'https://pchel.net/',
    name: 'pchel.net',
  },

  {
    id: 11,
    theme: 'Freelance',
    header3: 'Взять заказы',
    link: 'https://rubrain.com/',
    name: 'rubrain.com',
  },

  {
    id: 12,
    theme: 'Freelance',
    header3: 'Взять заказы',
    link: 'https://www.weblancer.net/',
    name: 'weblancer.net',
  },

  {
    id: 13,
    theme: 'Freelance',
    header3: 'Взять заказы',
    link: 'https://workspace.ru/freelance/',
    name: 'workspace.ru',
  },

  {
    id: 14,
    theme: 'Freelance',
    header3: 'Взять заказы',
    link: 'https://work-zilla.com/',
    name: 'work-zilla.com',
  },

  {
    id: 15,
    theme: 'Freelance',
    header3: 'Взять заказы',
    link: 'https://www.upwork.com/',
    name: 'upwork.com',
  },

  {
    id: 16,
    theme: 'Freelance',
    header3: 'Взять заказы',
    link: 'https://youdo.com/',
    name: 'youdo.com',
  },

  {},

];

export default dataFreelance;
