const dataVideoFigma = [

  {
    id: 1,
    year: 2019,
    date: '',
    category: 'other',
    theme: 'figma',
    title: 'Figma 3.0 для дизайнера',
    author: 'Антон Рыбаков',
    name: 'Skillbox',
    numberLessons: '',
    time_h_m: [13, 40],
    size: '6 gb',
    isLearned: true,
    dateLearned: '2021-11-23 вт',
  },

  {},

];

export default dataVideoFigma;
