// index.js корневой скрипт

// Стили
import './style.scss';
// Стили

import './components/header/header';
import './components/nav/nav';
import './components/footer/footer';
import './components/btn-up/btn-up';

console.log('200tb start');
