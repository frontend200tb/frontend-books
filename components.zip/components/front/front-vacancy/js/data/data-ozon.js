const dataOzon = [

  {
    id: 1,
    theme: 'Ozon',
    header3: 'Route 256 Ozon Tech',
    link: 'https://route256.ozon.ru/',
    name: 'route256.ozon.ru',
    text: 'Делимся IT-экспертизой Ozon и знакомим с воркфлоу команд',
  },

  {
    id: 2,
    theme: 'Ozon',
    header3: 'Route 256 Ozon Tech',
    link: 'https://route256.ozon.ru/c-sharp-junior',
    name: 'route256.ozon.ru/c-sharp-junior',
    text: 'Бесплатный курс «C#-разработчик»',
  },

  {
    id: 3,
    theme: 'Ozon',
    header3: 'Route 256 Ozon Tech',
    link: 'https://route256.ozon.ru/c-sharp',
    name: 'route256.ozon.ru/c-sharp',
    text: 'Продвинутая разработка микросервисов на C#',
  },

  {},

];

export default dataOzon;
