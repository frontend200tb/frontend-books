const dataVideoTilda = [

  {
    id: 1,
    year: 2020,
    date: '',
    category: 'cms',
    theme: 'tilda',
    title: 'Дизайнер сайтов на Tilda',
    author: '',
    name: 'Skillbox',
    numberLessons: '',
    time_h_m: [20, 0],
    size: '12.49 gb',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 2,
    year: 2020,
    date: '',
    category: 'cms',
    theme: 'tilda',
    title: 'Tilda Start',
    author: 'Максим Ширко',
    name: '',
    numberLessons: '',
    time_h_m: [20, 0],
    size: '12.2 gb',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 3,
    year: 2020,
    date: '',
    category: 'cms',
    theme: 'tilda',
    title: 'Тильда-мастер 2.0',
    author: 'Сергей Харюков',
    name: '',
    numberLessons: '',
    time_h_m: [6, 50],
    size: '7.1 gb',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataVideoTilda;
