const dataAvito = [

  {
    id: 1,
    theme: 'Avito',
    header3: 'Avito Tech',
    link: 'https://avito.tech/',
    name: 'avito.tech',
    text: 'AvitoTech — команда инженеров, которые ежедневно улучшают сервисы Авито и прокачивают себя.',
  },

  {
    id: 2,
    theme: 'Avito',
    header3: 'Avito Career',
    link: 'https://career.avito.com/',
    name: 'career.avito.com',
    text: 'Станьте частью команды Авито',
  },

  {
    id: 3,
    theme: 'Avito',
    header3: 'Avito Career',
    link: 'https://manifesto.avito.com/',
    name: 'manifesto.avito.com',
    text: 'Зачем существует Авито, и к чему мы стремимся',
  },

  {
    id: 4,
    theme: 'Avito',
    header3: 'Avito Start',
    link: 'https://start.avito.ru/',
    name: 'start.avito.ru',
    text: 'Это стажировки в Авито',
  },

  {},

];

export default dataAvito;
