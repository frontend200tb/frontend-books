const dataBooksDl = [

  {
    id: 1,
    year: 2018,
    category: 'theme',
    theme: 'Deep Learning',
    title: 'Глубокое обучение (2е)',
    author: 'Гудфеллоу',
    authorName: 'Ян',
    pages: '653',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 2,
    year: 2019,
    category: 'theme',
    theme: 'Deep Learning',
    title: 'Грокаем глубокое обучение',
    author: 'Траск',
    authorName: 'Эндрю',
    pages: '354',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 3,
    year: 2020,
    category: 'theme',
    theme: 'Deep Learning',
    title: 'Основы глубокого обучения',
    author: 'Будума',
    authorName: 'Нихиль',
    pages: '306',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 4,
    year: 2020,
    category: 'theme',
    theme: 'Deep Learning',
    title: 'Глубокое обучение для чайников',
    author: 'Мюллер',
    authorName: 'Джон',
    pages: '402',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 5,
    year: 2022,
    category: 'theme',
    theme: 'Deep Learning',
    title: 'Глубокое обучение. Самый краткий и понятный курс',
    author: 'Келлехер',
    authorName: 'Джон',
    pages: '162',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataBooksDl;
