const dataBooksMl = [

  {
    id: 1,
    year: 2017,
    category: 'theme',
    theme: 'Machine Learning',
    title: 'Машинное обучение',
    author: 'Бринк',
    authorName: 'Хенрик',
    pages: '338',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 2,
    year: 2020,
    category: 'theme',
    theme: 'Machine Learning',
    title: 'Машинное обучение без лишних слов',
    author: 'Бурков',
    authorName: 'Андрей',
    pages: '192',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataBooksMl;
