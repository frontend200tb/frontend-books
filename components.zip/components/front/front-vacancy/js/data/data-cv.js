const dataCv = [

  {
    id: 1,
    theme: 'CV',
    header2: 'Примеры CV в интернете',
  },

  {
    id: 2,
    theme: 'CV',
    header3: 'Взять заказы',
    link: 'https://www.fl.ru/',
    name: 'fl.ru',
  },

  {
    id: 3,
    theme: 'CV',
    header3: 'Взять заказы',
    link: 'https://freelance.ru/',
    name: 'freelance.ru',
  },

  {},

];

export default dataCv;
