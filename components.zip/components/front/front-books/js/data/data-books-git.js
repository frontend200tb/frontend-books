const dataBooksGit = [

  {
    id: 1,
    year: 2010,
    category: 'tools',
    theme: 'Git',
    title: 'Магия Git',
    author: 'Лин',
    authorName: 'Бен',
    pages: '49',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 2,
    year: 2016,
    category: 'tools',
    theme: 'Git',
    title: 'Git для профессионального программиста',
    author: 'Чакон',
    authorName: 'Скотт',
    pages: '496',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 3,
    year: 2018,
    category: 'tools',
    theme: 'Git',
    title: 'Git Методология разработки',
    author: 'Лебедюк',
    authorName: 'Эдуард',
    pages: '41',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 4,
    year: 2019,
    category: 'tools',
    theme: 'Git',
    title: 'Pro Git (2е)',
    author: 'Чакон',
    authorName: 'Скотт',
    pages: '533',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 5,
    year: 2021,
    category: 'tools',
    theme: 'Git',
    title: 'Git. Практическое руководство',
    author: 'Фишерман',
    pages: '306',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 6,
    year: 2024,
    category: 'tools',
    theme: 'Git',
    title: 'Head First. GIT. Лучший способ понять Git изнутри',
    author: 'Ганди',
    authorName: 'Раджу',
    pages: '466',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataBooksGit;
