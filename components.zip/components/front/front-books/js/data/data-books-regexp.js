const dataBooksRegexp = [

  {
    id: 1,
    year: 2003,
    category: 'tools',
    theme: 'RegExp',
    title: 'Регулярные выражения (2е)',
    author: 'Фридл',
    authorName: 'Джеффри',
    pages: '465',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 2,
    year: 2005,
    category: 'tools',
    theme: 'RegExp',
    title: 'Регулярные выражения. 10 минут на урок',
    author: 'Форта',
    authorName: 'Бен',
    pages: '175',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 3,
    year: 2008,
    category: 'tools',
    theme: 'RegExp',
    title: 'Регулярные выражения (3е)',
    author: 'Фридл',
    authorName: 'Джеффри',
    pages: '598',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 4,
    year: 2010,
    category: 'tools',
    theme: 'RegExp',
    title: 'Регулярные выражения. Сборник рецептов',
    author: 'Гойвертс',
    authorName: 'Ян',
    pages: '607',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 5,
    year: 2015,
    category: 'tools',
    theme: 'RegExp',
    title: 'Регулярные выражения. Основы',
    author: 'Фицджеральд',
    authorName: 'Майкл',
    pages: '144',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataBooksRegexp;
