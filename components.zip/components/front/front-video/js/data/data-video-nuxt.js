const dataVideoNuxt = [

  {
    id: 1,
    year: 2019,
    date: '',
    category: 'framework',
    theme: 'nuxt',
    title: 'Фреймворк NuxtJS. Full-Stack',
    author: 'Владилен Минин',
    name: 'WebForMySelf',
    numberLessons: '',
    time_h_m: [10, 57],
    size: '5.7 gb',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataVideoNuxt;
