const dataVideoBase = [

  {
    id: 1,
    year: 2015,
    date: '',
    category: 'основы',
    theme: 'Программирование',
    title: 'Основы программирования',
    author: '',
    name: 'CS50 Harvard',
    numberLessons: '23 урока',
    time_h_m: [20, 42],
    size: '7.4 gb',
    isLearned: true,
    dateLearned: '2021-06-10 чт',
  },

  {
    id: 2,
    year: 2018,
    date: '',
    category: 'основы',
    theme: 'Программирование',
    title: 'Ликбез будущего программиста',
    author: 'Альберт Степанцев',
    name: 'ProfIT',
    numberLessons: '6',
    time_h_m: [7, 29],
    size: '2.3 gb',
    isLearned: true,
    dateLearned: '2023-12-01 пт',
  },

  {
    id: 3,
    year: 2022,
    date: '2022.10.27',
    category: 'основы',
    theme: 'Программирование',
    title: 'Курс компьютерной грамотности для чайников',
    author: 'Елена Бредова',
    name: 'Geek Brains',
    numberLessons: '',
    time_h_m: [6, 46],
    size: '1.3 gb',
    isLearned: true,
    dateLearned: '2023-12-06 ср',
  },

  {},

];

export default dataVideoBase;
