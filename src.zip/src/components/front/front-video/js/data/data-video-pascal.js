const dataVideoPascal = [

  {
    id: 1,
    year: 2017,
    date: '2017-01-05',
    category: 'code',
    theme: 'pascal',
    title: 'Учим Pascal за 1 час !',
    author: '',
    name: 'David Hit',
    numberLessons: '',
    time_h_m: [1, 3],
    size: '94 mb',
    isLearned: true,
    dateLearned: '2024-02-05 пн',
  },


  {},

];

export default dataVideoPascal;
