const dataBooksSysadmin = [

  {
    id: 1,
    year: 2006,
    category: 'theme',
    theme: 'Системный администратор',
    title: 'Системное администрирование на 100%',
    author: 'Бормотов',
    authorName: 'Сергей',
    pages: '257',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 2,
    year: 2010,
    category: 'theme',
    theme: 'Системный администратор',
    title: 'Практическое руководство системного администратора',
    author: 'Кенин',
    authorName: 'Александр',
    pages: '459',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 3,
    year: 2012,
    category: 'theme',
    theme: 'Системный администратор',
    title: 'Самоучитель системного администратора (3е)',
    author: 'Кенин',
    authorName: 'Александр',
    pages: '512',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 4,
    year: 2013,
    category: 'theme',
    theme: 'Системный администратор',
    title: 'Практическое руководство системного администратора (2е)',
    author: 'Кенин',
    authorName: 'Александр',
    pages: '532',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 5,
    year: 2016,
    category: 'theme',
    theme: 'Системный администратор',
    title: 'Самоучитель системного администратора (4е)',
    author: 'Кенин',
    authorName: 'Александр',
    pages: '527',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 6,
    year: 2018,
    category: 'theme',
    theme: 'Системный администратор',
    title: 'Практика системного и сетевого администрирования. Том 1 (3е)',
    author: 'Лимончели',
    authorName: 'Томас',
    pages: '1106',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 7,
    year: 2019,
    category: 'theme',
    theme: 'Системный администратор',
    title: 'Самоучитель системного администратора (5е)',
    author: 'Кенин',
    authorName: 'Александр',
    pages: '608',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 8,
    year: 2021,
    category: 'theme',
    theme: 'Системный администратор',
    title: 'Основы администрирования информационных систем',
    author: 'Бобынцев',
    authorName: 'Денис',
    pages: '201',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 9,
    year: 2021,
    category: 'theme',
    theme: 'Системный администратор',
    title: 'Самоучитель системного администратора (6е)',
    author: 'Кенин',
    authorName: 'Александр',
    pages: '610',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataBooksSysadmin;
