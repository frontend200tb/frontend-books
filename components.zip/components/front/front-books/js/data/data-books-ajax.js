const dataBooksAjax = [

  {
    id: 1,
    year: 2007,
    category: 'tools',
    theme: 'Ajax',
    title: 'Ajax и PHP. Разработка динамических веб-приложений',
    author: 'Дари',
    authorName: 'Кристиан',
    pages: '334',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 2,
    year: 2009,
    category: 'tools',
    theme: 'Ajax',
    title: 'Ajax программирование для интернета',
    author: 'Бенкен',
    authorName: 'Елена',
    pages: '436',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 3,
    year: 2009,
    category: 'tools',
    theme: 'Ajax',
    title: 'Ajax на примерах',
    author: 'Овчаренко',
    authorName: 'Андрей',
    pages: '431',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataBooksAjax;
