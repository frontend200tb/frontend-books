const dataVideoBem = [

  {
    id: 1,
    year: 2016,
    date: '',
    category: 'other',
    theme: 'bem',
    title: 'БЭМ-платформа',
    author: 'Владимир Гриненко',
    name: 'frontend-science',
    numberLessons: '',
    time_h_m: [5, 50],
    size: '1.7 gb',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataVideoBem;
