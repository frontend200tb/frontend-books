const dataVideoDocker = [

  {
    id: 1,
    year: 2019,
    date: '',
    category: 'tools',
    theme: 'docker',
    title: 'Продвинутый видеокурс по Docker',
    author: '',
    name: 'Lectrum',
    numberLessons: '',
    time_h_m: [12, 50],
    size: '2.3 gb',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataVideoDocker;
