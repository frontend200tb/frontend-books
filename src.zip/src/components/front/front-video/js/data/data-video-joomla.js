const dataVideoJoomla = [

  {
    id: 1,
    year: 2015,
    date: '',
    category: 'cms',
    theme: 'joomla',
    title: 'Joomla-Профессионал',
    author: 'Виктор Гавриленко',
    name: 'WebForMySelf',
    numberLessons: '',
    time_h_m: [77, 25],
    size: '13.2 gb',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataVideoJoomla;
