const dataNeoflex = [

  {
    id: 1,
    theme: 'Neoflex',
    header3: 'Neoflex',
    link: 'https://www.neoflex.ru/',
    name: 'neoflex.ru',
  },

  {
    id: 2,
    theme: 'Neoflex',
    header3: 'Neoflex вакансии',
    link: 'https://www.neoflex.ru/about/career',
    name: 'neoflex.ru/about/career',
  },

  {
    id: 3,
    theme: 'Neoflex',
    header3: 'Neoflex учебный центр',
    link: 'https://edu.neoflex.ru/',
    name: 'edu.neoflex.ru',
  },

  {
    id: 4,
    theme: 'Neoflex',
    header3: 'Neoflex учебный центр',
    link: 'https://edu.neoflex.ru/frontend',
    name: 'edu.neoflex.ru/frontend',
  },

  {
    id: 5,
    theme: 'Neoflex',
    header3: 'Neoflex учебный центр',
    link: 'https://neostudy.neoflex.ru/',
    name: 'neostudy.neoflex.ru',
  },

  {
    id: 6,
    theme: 'Neoflex',
    header3: 'Тест по английскому',
    link: 'https://www.ef.ru/test/',
    name: 'ef.ru/test',
  },

  {
    id: 6,
    theme: 'Neoflex',
    header3: 'Тест по английскому',
    link: 'https://www.efset.org/ru/quick-check/',
    name: 'efset.org/ru/quick-check',
  },

  {
    id: 6,
    theme: 'Neoflex',
    header3: 'React',
    link: 'https://ru.hexlet.io/blog/posts/react-router-v6',
    name: 'ru.hexlet.io/blog/posts/react-router-v6',
  },

  {},

];

export default dataNeoflex;
