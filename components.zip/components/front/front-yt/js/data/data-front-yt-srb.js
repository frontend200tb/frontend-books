const dataFrontYtSrb = [

  {
    id: 1,
    theme: 'frontend srb',
    title: 'cysecor',
    author: '',
    city: '',
    country: 'Сербия',
    link: 'https://www.youtube.com/@cysecor/videos',
    site: '',
    dateFirstVideo: '2020.02.19',
    dateLastVideo: '2022.12.14',
    amountVideos: 116,
  },

  {
    id: 2,
    theme: 'frontend srb',
    title: 'RIS HUB UE',
    author: '',
    city: '',
    country: 'Сербия',
    link: 'https://www.youtube.com/@rishubue/videos',
    site: '',
    dateFirstVideo: '2020.10.29',
    dateLastVideo: '2022.11.03',
    amountVideos: 103,
  },

  {},

];

export default dataFrontYtSrb;
