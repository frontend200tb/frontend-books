const dataNeoflex = [

  {
    id: 1,
    theme: 'Neoflex',
    header3: 'Neoflex',
    link: 'https://www.neoflex.ru/',
    name: 'neoflex.ru',
  },

  {
    id: 2,
    theme: 'Neoflex',
    header3: 'Neoflex вакансии',
    link: 'https://www.neoflex.ru/about/career',
    name: 'neoflex.ru/about/career',
  },

  {
    id: 3,
    theme: 'Neoflex',
    header3: 'Neoflex учебный центр',
    link: 'https://edu.neoflex.ru/',
    name: 'edu.neoflex.ru',
  },

  {
    id: 4,
    theme: 'Neoflex',
    header3: 'Neoflex учебный центр',
    link: 'https://edu.neoflex.ru/frontend',
    name: 'edu.neoflex.ru/frontend',
  },

  {},

];

export default dataNeoflex;
