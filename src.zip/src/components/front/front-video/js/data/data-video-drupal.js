const dataVideoDrupal = [

  {
    id: 1,
    year: 2017,
    date: '',
    category: 'cms',
    theme: 'drupal',
    title: 'Drupal Основы',
    author: 'Виктор Гавриленко',
    name: 'WebForMySelf',
    numberLessons: '',
    time_h_m: [6, 30],
    size: '0.8 gb',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataVideoDrupal;
