const dataVideoYii2 = [

  {
    id: 1,
    year: 2020,
    date: '',
    category: 'framework',
    theme: 'yii2',
    title: 'Фреймворк Yii2',
    author: 'Андрей Кудлай',
    name: 'WebForMySelf',
    numberLessons: '',
    time_h_m: [22, 28],
    size: '9.5 gb',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataVideoYii2;
