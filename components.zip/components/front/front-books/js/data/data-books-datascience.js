const dataBooksDataScience = [

  {
    id: 1,
    year: 2017,
    category: 'theme',
    theme: 'Data Science',
    title: 'Data Science. Наука о данных с нуля',
    author: 'Грас',
    authorName: 'Джоэл',
    pages: '337',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 2,
    year: 2020,
    category: 'theme',
    theme: 'Data Science',
    title: 'Наука о данных',
    author: 'Скиена',
    authorName: 'Стивен',
    pages: '544',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 3,
    year: 2021,
    category: 'theme',
    theme: 'Data Science',
    title: 'Практическая статистика Data Science (2е)',
    author: 'Брюс',
    authorName: 'Питер',
    pages: '354',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 4,
    year: 2021,
    category: 'theme',
    theme: 'Data Science',
    title: 'Теоретический минимум по Big Data',
    author: 'Ын',
    authorName: 'Анналин',
    pages: '208',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataBooksDataScience;
