const dataBooksGraphql = [

  {
    id: 1,
    year: 2019,
    category: 'tools',
    theme: 'GraphQL',
    title: 'GraphQL язык запросов',
    author: 'Бэнкс',
    authorName: 'Алекс',
    pages: '240',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 2,
    year: 2023,
    category: 'tools',
    theme: 'GraphQL',
    title: 'Разработка веб приложений GraphQL React',
    author: 'Лион',
    authorName: 'Уильям',
    pages: '264',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataBooksGraphql;
