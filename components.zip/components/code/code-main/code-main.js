/** *******************
Скрипт из файла code-main.js
Функция showCode показывает страницу code
******************** */
import './element-code-main';

export default function showCode() { }
