const dataVideo1cbitrix = [

  {
    id: 1,
    year: 2013,
    date: '',
    category: 'cms',
    theme: '1cbitrix',
    title: 'Создание сайта на 1С Битрикс с нуля',
    author: 'Михаил Базаров',
    name: 'camouf.ru',
    numberLessons: '14 уроков',
    time_h_m: [6, 23],
    size: '4.8 gb',
    isLearned: true,
    dateLearned: '2021-06-11 пт',
  },

  {
    id: 2,
    year: 2018,
    date: '',
    category: 'cms',
    theme: '1cbitrix',
    title: '1С-Битрикс',
    author: 'Андрей Кудлай',
    name: 'WebForMySelf',
    numberLessons: '',
    time_h_m: [38, 38],
    size: '8.2 gb',
    isLearned: false,
    dateLearned: '',
  },

  {},
];

export default dataVideo1cbitrix;
