const dataVacancy = [

  {
    id: 1,
    theme: 'Vacancy',
    header2: 'easyoffer',
  },

  {
    id: 2,
    theme: 'Vacancy',
    header3: 'easyoffer',
    link: 'https://easyoffer.ru/',
    name: 'easyoffer.ru',
  },

  {
    id: 2,
    theme: 'Vacancy',
    header3: 'easyoffer',
    link: 'https://github.com/kivaiko/easyoffer',
    name: 'github.com/kivaiko/easyoffer',
  },

  {
    id: 1,
    theme: 'Vacancy',
    header2: 'Задачи',
  },

  {
    id: 2,
    theme: 'Vacancy',
    header3: 'Задачи',
    link: 'https://www.codewars.com/',
    name: 'codewars.com',
  },

  {
    id: 2,
    theme: 'Vacancy',
    header3: 'Задачи',
    link: 'https://leetcode.com/',
    name: 'leetcode.com',
  },

  {
    id: 2,
    theme: 'Vacancy',
    header3: 'Задачи',
    link: 'https://coderun.yandex.ru/',
    name: 'coderun.yandex.ru',
  },

  {
    id: 1,
    theme: 'Vacancy',
    header2: 'Вакансии',
  },

  {
    id: 2,
    theme: 'Vacancy',
    header3: 'Вакансии',
    link: 'https://hh.ru/',
    name: 'hh.ru',
  },

  {
    id: 2,
    theme: 'Vacancy',
    header3: 'Вакансии',
    link: 'https://school.hh.ru/',
    name: 'school.hh.ru',
  },

  {
    id: 3,
    theme: 'Vacancy',
    header3: 'Вакансии',
    link: 'https://career.habr.com/',
    name: 'career.habr.com',
  },

  {
    id: 4,
    theme: 'Vacancy',
    header3: 'Вакансии',
    link: 'https://getmatch.ru/',
    name: 'getmatch.ru',
  },

  {
    id: 5,
    theme: 'Vacancy',
    header3: 'Вакансии',
    link: 'https://www.rabota.ru/',
    name: 'rabota.ru',
  },

  {
    id: 5,
    theme: 'Vacancy',
    header3: 'Вакансии',
    link: 'https://vc.ru/job',
    name: 'vc.ru/job',
  },

  {},

];

export default dataVacancy;
