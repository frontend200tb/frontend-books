const dataBooksVue = [

  {
    id: 1,
    year: 2019,
    category: 'framework',
    theme: 'vue',
    title: 'Vue.js в действии',
    author: 'Хэнчетт',
    author: 'Эрик',
    pages: '306',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataBooksVue;
