const dataBooksAngular = [

  {
    id: 1,
    year: 2017,
    category: 'framework',
    theme: 'angular',
    title: 'Изучаем Angular 2',
    author: 'Дилеман',
    authorName: 'Пабло',
    pages: '357',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 2,
    year: 2017,
    category: 'framework',
    theme: 'angular',
    title: 'Стек MEAN. Mongo, Express, Angular, Node',
    author: 'Холмс',
    authorName: 'Саймон',
    pages: '496',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 3,
    year: 2018,
    category: 'framework',
    theme: 'angular',
    title: 'Angular и TypeScript',
    author: 'Файн',
    authorName: 'Яков',
    pages: '464',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 4,
    year: 2018,
    category: 'framework',
    theme: 'angular',
    title: 'Angular для профессионалов (2е)',
    author: 'Фримен',
    authorName: 'Адам',
    pages: '800',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 5,
    year: 2018,
    category: 'framework',
    theme: 'angular',
    title: 'Angular. Сборник рецептов',
    author: 'Фрисби',
    authorName: 'Мэтт',
    pages: '466',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataBooksAngular;
