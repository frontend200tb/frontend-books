const dataYtPascal = [

  {
    id: 1,
    theme: 'Pascal',
    title: 'Эдуард Мецкер',
    author: 'Эдуард Мецкер',
    city: '',
    country: '',
    link: 'https://www.youtube.com/@German707707/videos',
    site: '',
    dateFirstVideo: '2011.01.23',
    dateLastVideo: '2016.11.02',
    amountVideos: 17,
  },

  {
    id: 2,
    theme: 'Pascal',
    title: 'Дмитрий Лапко',
    author: 'Дмитрий Лапко',
    city: '',
    country: '',
    link: 'https://www.youtube.com/@user-yn1pi7kf7c/videos',
    site: '',
    dateFirstVideo: '2015.12.22',
    dateLastVideo: '2018.12.18',
    amountVideos: 16,
  },


  {},

];

export default dataYtPascal;
