const dataVideoBootstrap = [

  {
    id: 1,
    year: 2014,
    date: '',
    category: 'framework',
    theme: 'bootstrap',
    title: 'Bootstrap 3 Добавь интерактивности на свой сайт',
    author: 'Jen Kramer',
    name: 'Lynda.com',
    numberLessons: '5 уроков',
    time_h_m: [1, 56],
    size: '0.4 gb',
    isLearned: true,
    dateLearned: '2021-07-19 пн',
  },

  {
    id: 2,
    year: 2015,
    date: '',
    category: 'framework',
    theme: 'bootstrap',
    title: 'Курс Bootstrap',
    author: 'Сергей Никонов',
    name: 'wh-db.com',
    numberLessons: '8 уроков',
    time_h_m: [3, 31],
    size: '1.2 gb',
    isLearned: true,
    dateLearned: '2021-08-14 сб',
  },

  {
    id: 3,
    year: 2016,
    date: '',
    category: 'framework',
    theme: 'bootstrap',
    title: 'Фреймворк Bootstrap от А до Я',
    author: 'Андрей Кудлай',
    name: 'WebForMyself',
    numberLessons: '',
    time_h_m: [24, 44],
    size: '6 gb',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataVideoBootstrap;
