const dataSber = [

  {
    id: 1,
    theme: 'Сбер',
    header3: 'Сбер',
    link: 'https://developers.sber.ru/kak-v-sbere/vacancies/frontend-developer-sd',
    name: 'developers.sber.ru',
  },

  {
    id: 2,
    theme: 'Сбер',
    header3: 'Сбер учебный центр',
    link: 'https://sberuniversity.ru/',
    name: 'sberuniversity.ru',
    text: 'У студентов бесплатного курса JS Bootcamp 2023 будет наставник, с которым можно лично созваниваться. На обучение мы возьмем до 15 человек (студентов и слушателей), которых определим по результатам входного тестирования.',
  },

  {
    id: 3,
    theme: 'Сбер',
    header3: 'Сбер школа 21',
    link: 'https://21-school.ru/',
    name: '21-school.ru',
    text: 'Школа 21 программирование с нуля для тех, кто хочет Сменить профессию Найти себя в ИТ Получить практические знания',
  },

  {},

];

export default dataSber;
