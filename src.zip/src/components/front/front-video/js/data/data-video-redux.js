const dataVideoRedux = [

  {
    id: 1,
    year: 2017,
    date: '',
    category: 'framework',
    theme: 'redux',
    title: 'Основы Redux',
    author: '',
    name: 'CodeDojo',
    numberLessons: '',
    time_h_m: [2, 30],
    size: '0.5 gb',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 2,
    year: 2019,
    date: '',
    category: 'framework',
    theme: 'redux',
    title: 'Продвинутый видеокурс по Redux',
    author: '',
    name: 'Lectrum',
    numberLessons: '',
    time_h_m: [27, 51],
    size: '7.1 gb',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 3,
    year: 2019,
    date: '',
    category: 'framework',
    theme: 'redux',
    title: 'Продвинутый видеокурс по Redis',
    author: '',
    name: 'Lectrum',
    numberLessons: '',
    time_h_m: [9, 6],
    size: '1.3 gb',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataVideoRedux;
