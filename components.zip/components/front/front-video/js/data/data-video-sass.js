const dataVideoSass = [

  {
    id: 1,
    year: 2017,
    date: '',
    category: 'code',
    theme: 'sass',
    title: 'Препроцессоры Sass и Less',
    author: 'Владилен Минин',
    name: 'WebForMySelf',
    numberLessons: '',
    time_h_m: [35, 0],
    size: '2.1 gb',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataVideoSass;
