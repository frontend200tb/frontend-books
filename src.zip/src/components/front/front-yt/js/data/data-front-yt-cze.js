const dataFrontYtCze = [
  {
    id: 1,
    theme: 'frontend cze',
    title: 'David Šetek - Hackni svou budoucnost',
    author: 'David Šetek',
    city: '',
    country: 'Чехия',
    link: 'https://www.youtube.com/@hacknisvoubudoucnost/videos',
    site: '',
    dateFirstVideo: '2019.12.15',
    dateLastVideo: '2023.01.02',
    amountVideos: 1399,
  },

  {
    id: 2,
    theme: 'frontend cze',
    title: 'ROB WEB s yablkom',
    author: 'ROB',
    city: '',
    country: 'Чехия',
    link: 'https://www.youtube.com/@RobWebSK/videos',
    site: '',
    dateFirstVideo: '2020.06.08',
    dateLastVideo: '2022.09.23',
    amountVideos: 68,
  },

  {},

];

export default dataFrontYtCze;
