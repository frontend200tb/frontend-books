const dataVideoOpencart = [

  {
    id: 1,
    year: 2017,
    date: '',
    category: 'cms',
    theme: 'opencart',
    title: 'OpenCart - Создание интернет-магазина от А до Я',
    author: '',
    name: 'webdesign-master',
    numberLessons: '',
    time_h_m: [11, 54],
    size: '10.3 gb',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataVideoOpencart;
