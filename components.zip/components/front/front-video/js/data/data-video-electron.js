const dataVideoElectron = [

  {
    id: 1,
    year: 2019,
    date: '2019-03-23',
    category: 'framework',
    theme: 'electron',
    title: 'Создание ПК программы на JavaScript  за 20 минут! Библиотека Electron JS',
    author: 'Гоша Дударь',
    name: '',
    numberLessons: '',
    time_h_m: [0, 22],
    size: '33 mb',
    isLearned: true,
    dateLearned: '2023-01-20 пт',
  },

  {
    id: 2,
    year: 2021,
    date: '2021-03-18',
    category: 'framework',
    theme: 'electron',
    title: 'Electron. Как работает самый современный desktop framework',
    author: 'Алексей Голубев',
    name: 'itvdn',
    numberLessons: '',
    time_h_m: [1, 19],
    size: '175 mb',
    isLearned: true,
    dateLearned: '2023-01-27 пт',
  },

  {
    about: 'The Electron framework lets you write cross-platform desktop applications using JavaScript, HTML and CSS. It is based on Node.js and Chromium and is used by the Atom editor and many other apps.',
  },

];

export default dataVideoElectron;
