const dataBooksDocker = [

  {
    id: 1,
    year: 2019,
    category: 'tools',
    theme: 'Docker',
    title: 'Микросервисы и контейнеры Docker',
    author: 'Кочер',
    authorName: 'Парминдер',
    pages: '240',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 2,
    year: 2020,
    category: 'tools',
    theme: 'Docker',
    title: 'Docker на практике',
    author: 'Мил',
    authorName: 'Иан',
    pages: '516',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 3,
    year: 2023,
    category: 'tools',
    theme: 'Docker',
    title: 'Контейнеризатор приложений Docker',
    author: 'Ананченко',
    authorName: 'Игорь',
    pages: '57',
    isLearned: false,
    dateLearned: '',
  },

  {
    id: 4,
    year: 2023,
    category: 'tools',
    theme: 'Docker',
    title: 'Docker Compose для разработчика',
    author: 'Гадзурас',
    authorName: 'Эммануил',
    pages: '221',
    isLearned: false,
    dateLearned: '',
  },

  {},

];

export default dataBooksDocker;
